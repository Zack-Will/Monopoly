package Monopoly;

import javafx.scene.control.Button;

public class MainController {
    public Button StartButton;
    public void StartButtonClick() throws Exception
    {
        Main.changeToSelect();
    }
}
